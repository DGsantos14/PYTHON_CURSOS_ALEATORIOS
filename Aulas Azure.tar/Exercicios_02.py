date = input("Qual a data atual? ")

cafe_da_manha = int(input("Calorias ingeridas no café da manhã? "))

almoco = int(input("Calorias ingeridas no almoço? "))

lanche  = int(input("Calorias ingeridas no lanche? "))

jantar = int(input("Calorias ingeridas no jantar? "))


total = (cafe_da_manha + lanche + jantar + almoco)
calorias = [date, cafe_da_manha, almoco, lanche, jantar]

print("TotaL de calorias ingeridas: " + date + ": " + str(total))