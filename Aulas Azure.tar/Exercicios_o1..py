# Progama para calcular 

numero_01 = int(input("Informe um número! "))

numero_02 = int(input("Informe o segundo número! "))

soma_total = numero_01 = numero_02

media = int(soma_total / 2)
print("A media eh igual a", media)