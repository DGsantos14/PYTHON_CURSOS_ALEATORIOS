valor_1 = input("Informe um numer de 1 a 7 "/n )

if valor_1 == 7:
    print("O valor é ")
else:
    print("O valor não é 7! " )